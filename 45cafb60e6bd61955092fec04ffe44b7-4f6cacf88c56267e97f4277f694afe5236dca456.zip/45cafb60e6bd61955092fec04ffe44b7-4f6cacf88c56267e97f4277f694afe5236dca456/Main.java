package Snake;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // Adjust the path if Snake.fxml is in the same package as this Main class
        Parent root = FXMLLoader.load(getClass().getResource("Snake.fxml"));
        primaryStage.setTitle("Bible Snake Game");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


