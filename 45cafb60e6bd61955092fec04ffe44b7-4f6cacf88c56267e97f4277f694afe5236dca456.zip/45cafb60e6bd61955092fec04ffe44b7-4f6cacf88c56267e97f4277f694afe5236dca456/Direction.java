package Snake;

public enum Direction {
    UP, DOWN, RIGHT, LEFT
}
